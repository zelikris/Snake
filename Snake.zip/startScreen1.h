#ifndef STARTSCREEN1_BITMAP_H
#define STARTSCREEN1_BITMAP_H
extern const unsigned short startScreen1[38400];
#define STARTSCREEN1_WIDTH 240
#define STARTSCREEN1_HEIGHT 160
#endif