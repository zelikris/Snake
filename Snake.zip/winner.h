#ifndef WINNER_BITMAP_H
#define WINNER_BITMAP_H
extern const unsigned short winner[38400];
#define WINNER_WIDTH 240
#define WINNER_HEIGHT 160
#endif