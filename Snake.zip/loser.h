#ifndef LOSER_BITMAP_H
#define LOSER_BITMAP_H
extern const unsigned short loser[38400];
#define LOSER_WIDTH 240
#define LOSER_HEIGHT 160
#endif