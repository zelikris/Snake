#ifndef LOSESCREEN_BITMAP_H
#define LOSESCREEN_BITMAP_H
extern const unsigned short loseScreen[38400];
#define LOSESCREEN_WIDTH 240
#define LOSESCREEN_HEIGHT 160
#endif