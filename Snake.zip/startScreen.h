// Kristian Zhelyazkov

#ifndef STARTSCREEN_BITMAP_H
#define STARTSCREEN_BITMAP_H
extern const unsigned short startScreen[38400];
#define STARTSCREEN_WIDTH 240
#define STARTSCREEN_HEIGHT 160
#endif
